document.addEventListener('DOMContentLoaded', function () {
    let map;
    let markers = [];

    // Initialize the map
    map = L.map('map').setView([34.0522, -118.2437], 10); // Default to Los Angeles

    // Load a tile layer
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    // Fetch and load the location data
    fetch('/data/Millard_Sheets_Studio_Locations.json')
        .then(response => response.json())
        .then(data => {
            loadLocations(data);
            document.getElementById('filter').addEventListener('input', () => filterLocations(data));
        })
        .catch(error => console.error('Error loading the JSON data:', error));
});

function loadLocations(locations) {
    const locationContainer = document.getElementById('locations');
    locationContainer.innerHTML = '';
    markers.forEach(marker => map.removeLayer(marker));
    markers = [];

    locations.forEach(location => {
        if (location.Latitude && location.Longitude) {
            const marker = L.marker([location.Latitude, location.Longitude])
                .addTo(map)
                .bindPopup(`<b>${location.Firm}</b><br>${location.Address}<br>${location.City}, ${location.State}`);

            markers.push(marker);

            const card = document.createElement('div');
            card.className = 'card';
            card.innerHTML = `<strong>${location.Firm}</strong><br>${location.Address}<br>${location.City}, ${location.State}`;
            card.addEventListener('click', () => {
                map.setView(marker.getLatLng(), 15);
                marker.openPopup();
            });
            locationContainer.appendChild(card);
        }
    });
}

function filterLocations(locations) {
    const filterText = document.getElementById('filter').value.toLowerCase();
    const filteredLocations = locations.filter(location =>
        location.City && location.City.toLowerCase().includes(filterText)
    );
    loadLocations(filteredLocations);
}
